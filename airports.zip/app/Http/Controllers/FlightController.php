<?php

namespace App\Http\Controllers;

use App\Http\Requests\FlightSearchRequest;
use App\Models\Airport;
use App\Models\Booking;
use App\Models\Flight;
use Illuminate\Http\Request;

class FlightController extends Controller
{
    public function search(FlightSearchRequest $request)
    {
        return Booking::find(1)->flightBack;
    }
}
