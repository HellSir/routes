<?php

namespace App\Http\Controllers;

use App\Http\Requests\SetSeatRequest;
use App\Http\Resources\BookingResource;
use App\Http\Resources\OccupiedSeatFromResource;
use App\Http\Resources\OccupiedSeatsBackResource;
use App\Http\Resources\OccupiedSeatsFromResource;
use App\Http\Resources\PassengerResource;
use App\Models\Booking;
use App\Models\Passenger;
use App\Models\User;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function getOne($code)
    {
        $booking = Booking::where(['code' => $code])->first();

        return new BookingResource($booking);
    }

    public function getOccupiedSeats($code)
    {
        $booking = Booking::where(['code' => $code])->first();

        return response()->json([
            'data' => [
                new OccupiedSeatsFromResource($booking->occupiedFrom),
                new OccupiedSeatsBackResource($booking->occupiedBack)
            ]
        ]);
    }

    public function setSeat(SetSeatRequest $request, $code)
    {
        $booking = Booking::where(['code' => $code])->first();
        $passenger = Passenger::find($request->passenger);
        $user = User::where(['api_token' => $request->bearerToken()])->first();

        if ($user->document_number !== $passenger->document_number)
            return response()->json([
                'error' => [
                    'code' => 403,
                    'message' => 'Passenger does not apply to booking'
                ]
            ])->setStatusCode(403, 'Passenger does not aply to booking');

        if ($request->type === 'from' && Passenger::where(['booking_id' => $booking->id, 'place_from' => $request->seat])->first() ||
        $request->type === 'back' && Passenger::where(['booking_id' => $booking->id, 'place_back' => $request->seat])->first())
            return response()->json([
                'error' => [
                    'code' => 422,
                    'message' => 'Seat is occupied'
                ]
            ])->setStatusCode(422, 'Seat is occupied');

        if ($request->type === 'from')
            $passenger->update(['place_from' => $request->seat]);

        if ($request->type === 'back')
            $passenger->update(['place_back' => $request->seat]);

        return new PassengerResource($passenger);
    }
}
